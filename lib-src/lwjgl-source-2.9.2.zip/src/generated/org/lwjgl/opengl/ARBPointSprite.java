/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBPointSprite {

	/**
	 *  Accepted by the &lt;cap&gt; parameter of Enable, Disable, and IsEnabled, by
	 *  the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv, GetFloatv, and
	 *  GetDoublev, and by the &lt;target&gt; parameter of TexEnvi, TexEnviv,
	 *  TexEnvf, TexEnvfv, GetTexEnviv, and GetTexEnvfv:
	 */
	public static final int GL_POINT_SPRITE_ARB = 0x8861;

	/**
	 *  When the &lt;target&gt; parameter of TexEnvf, TexEnvfv, TexEnvi, TexEnviv,
	 *  GetTexEnvfv, or GetTexEnviv is POINT_SPRITE_ARB, then the value of
	 *  &lt;pname&gt; may be:
	 */
	public static final int GL_COORD_REPLACE_ARB = 0x8862;

	private ARBPointSprite() {}
}
