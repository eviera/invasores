/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTTextureSwizzle {

	/**
	 *  Accepted by the &lt;pname&gt; parameters of TexParameteri,
	 *  TexParameterf, TexParameteriv, TexParameterfv,
	 *  GetTexParameterfv, and GetTexParameteriv:
	 */
	public static final int GL_TEXTURE_SWIZZLE_R_EXT = 0x8E42,
		GL_TEXTURE_SWIZZLE_G_EXT = 0x8E43,
		GL_TEXTURE_SWIZZLE_B_EXT = 0x8E44,
		GL_TEXTURE_SWIZZLE_A_EXT = 0x8E45;

	/**
	 *  Accepted by the &lt;pname&gt; parameters of TexParameteriv,
	 *  TexParameterfv, GetTexParameterfv, and GetTexParameteriv:
	 */
	public static final int GL_TEXTURE_SWIZZLE_RGBA_EXT = 0x8E46;

	private EXTTextureSwizzle() {}
}
