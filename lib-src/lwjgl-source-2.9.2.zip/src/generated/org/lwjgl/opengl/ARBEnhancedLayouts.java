/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBEnhancedLayouts {

	/**
	 * Accepted in the &lt;props&gt; array of GetProgramResourceiv: 
	 */
	public static final int GL_LOCATION_COMPONENT = 0x934A,
		GL_TRANSFORM_FEEDBACK_BUFFER_INDEX = 0x934B,
		GL_TRANSFORM_FEEDBACK_BUFFER_STRIDE = 0x934C;

	private ARBEnhancedLayouts() {}
}
