/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBTextureRGB10_A2UI {

	/**
	 *  Accepted by the &lt;internalFormat&gt; parameter of TexImage1D, TexImage2D,
	 *  TexImage3D, CopyTexImage1D, CopyTexImage2D, RenderbufferStorage and
	 *  RenderbufferStorageMultisample:
	 */
	public static final int GL_RGB10_A2UI = 0x906F;

	private ARBTextureRGB10_A2UI() {}
}
