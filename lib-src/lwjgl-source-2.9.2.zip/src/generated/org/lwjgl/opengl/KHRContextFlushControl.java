/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class KHRContextFlushControl {

	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetIntegerv, GetFloatv, GetBooleanv
	 *  GetDoublev and GetInteger64v:
	 */
	public static final int GL_CONTEXT_RELEASE_BEHAVIOR = 0x82FB;

	/**
	 *  Returned in &lt;data&gt; by GetIntegerv, GetFloatv, GetBooleanv
	 *  GetDoublev and GetInteger64v when &lt;pname&gt; is
	 *  GL_CONTEXT_RELEASE_BEHAVIOR:
	 */
	public static final int GL_CONTEXT_RELEASE_BEHAVIOR_FLUSH = 0x82FC;

	private KHRContextFlushControl() {}
}
