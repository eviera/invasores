/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTTextureCompressionRGTC {

	/**
	 *  Accepted by the &lt;internalformat&gt; parameter of TexImage2D,
	 *  CopyTexImage2D, and CompressedTexImage2D and the &lt;format&gt; parameter
	 *  of CompressedTexSubImage2D:
	 */
	public static final int GL_COMPRESSED_RED_RGTC1_EXT = 0x8DBB,
		GL_COMPRESSED_SIGNED_RED_RGTC1_EXT = 0x8DBC,
		GL_COMPRESSED_RED_GREEN_RGTC2_EXT = 0x8DBD,
		GL_COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT = 0x8DBE;

	private EXTTextureCompressionRGTC() {}
}
