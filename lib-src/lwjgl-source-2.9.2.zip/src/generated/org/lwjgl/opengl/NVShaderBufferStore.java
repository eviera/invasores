/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVShaderBufferStore {

	/**
	 * Accepted by the &lt;barriers&gt; parameter of MemoryBarrierNV: 
	 */
	public static final int GL_SHADER_GLOBAL_ACCESS_BARRIER_BIT_NV = 0x10;

	private NVShaderBufferStore() {}
}
