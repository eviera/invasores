/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBConditionalRenderInverted {

	/**
	 * Accepted by the &lt;mode&gt; parameter of BeginConditionalRender: 
	 */
	public static final int GL_QUERY_WAIT_INVERTED = 0x8E17,
		GL_QUERY_NO_WAIT_INVERTED = 0x8E18,
		GL_QUERY_BY_REGION_WAIT_INVERTED = 0x8E19,
		GL_QUERY_BY_REGION_NO_WAIT_INVERTED = 0x8E1A;

	private ARBConditionalRenderInverted() {}
}
