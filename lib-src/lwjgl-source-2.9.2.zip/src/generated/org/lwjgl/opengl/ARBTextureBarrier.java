/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBTextureBarrier {

	private ARBTextureBarrier() {}

	public static void glTextureBarrier() {
		GL45.glTextureBarrier();
	}
}
