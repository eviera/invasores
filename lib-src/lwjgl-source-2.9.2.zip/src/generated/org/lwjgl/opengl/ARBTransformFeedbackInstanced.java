/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBTransformFeedbackInstanced {

	private ARBTransformFeedbackInstanced() {}

	public static void glDrawTransformFeedbackInstanced(int mode, int id, int primcount) {
		GL42.glDrawTransformFeedbackInstanced(mode, id, primcount);
	}

	public static void glDrawTransformFeedbackStreamInstanced(int mode, int id, int stream, int primcount) {
		GL42.glDrawTransformFeedbackStreamInstanced(mode, id, stream, primcount);
	}
}
