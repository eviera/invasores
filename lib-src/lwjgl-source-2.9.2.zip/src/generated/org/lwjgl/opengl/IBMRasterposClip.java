/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class IBMRasterposClip {

	/**
	 *  Accepted by the &lt;target&gt; parameter of Enable and Disable and the &lt;value&gt;
	 *  parameter of IsEnabled, GetBooleanv, GetIntegerv, GetFloatv, GetDoublev:
	 */
	public static final int GL_RASTER_POSITION_UNCLIPPED_IBM = 0x19262;

	private IBMRasterposClip() {}
}
