/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBCullDistance {

	/**
	 * Accepted by the &lt;pname&gt; parameter of GetBooeleanv, GetDoublev, GetFloatv GetIntegerv, and GetInteger64v: 
	 */
	public static final int GL_MAX_CULL_DISTANCES = 0x82F9,
		GL_MAX_COMBINED_CLIP_AND_CULL_DISTANCES = 0x82FA;

	private ARBCullDistance() {}
}
