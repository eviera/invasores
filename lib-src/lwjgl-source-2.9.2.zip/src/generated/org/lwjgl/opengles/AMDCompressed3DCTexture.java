/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class AMDCompressed3DCTexture {

	/**
	 *  Accepted by the &lt;internalFormat&gt; parameter of CompressedTexImage2D and
	 *  CompressedTexImage3DOES:
	 */
	public static final int GL_3DC_X_AMD = 0x87F9,
		GL_3DC_XY_AMD = 0x87FA;

	private AMDCompressed3DCTexture() {}
}
