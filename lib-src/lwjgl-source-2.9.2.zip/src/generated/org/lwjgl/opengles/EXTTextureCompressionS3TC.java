/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class EXTTextureCompressionS3TC {

	/**
	 *  Accepted by the &lt;internalformat&gt; parameter of TexImage2D, CopyTexImage2D,
	 *  and CompressedTexImage2D and the &lt;format&gt; parameter of
	 *  CompressedTexSubImage2D:
	 */
	public static final int GL_COMPRESSED_RGB_S3TC_DXT1_EXT = 0x83F0,
		GL_COMPRESSED_RGBA_S3TC_DXT1_EXT = 0x83F1,
		GL_COMPRESSED_RGBA_S3TC_DXT3_EXT = 0x83F2,
		GL_COMPRESSED_RGBA_S3TC_DXT5_EXT = 0x83F3;

	private EXTTextureCompressionS3TC() {}
}
