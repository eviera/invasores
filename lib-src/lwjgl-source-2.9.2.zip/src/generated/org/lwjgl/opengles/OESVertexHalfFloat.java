/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class OESVertexHalfFloat {

	/**
	 * Accepted by the &lt;type&gt; parameter of VertexAttribPointer: 
	 */
	public static final int GL_HALF_FLOAT_OES = 0x8D61;

	private OESVertexHalfFloat() {}
}
