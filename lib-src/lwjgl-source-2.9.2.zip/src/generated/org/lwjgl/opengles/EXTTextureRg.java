/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class EXTTextureRg {

	/**
	 *  Accepted by the &lt;internalformat&gt; parameter of TexImage2D and CopyTexImage2D,
	 *  and the &lt;format&gt; parameter of TexImage2D, TexSubImage2D, and ReadPixels:
	 */
	public static final int GL_RED_EXT = 0x1903,
		GL_RG_EXT = 0x8227;

	/**
	 *  Accepted by the &lt;internalformat&gt; parameter of RenderbufferStorage and
	 *  RenderbufferStorageMultisampleAPPLE:
	 */
	public static final int GL_R8_EXT = 0x8229,
		GL_RG8_EXT = 0x822B;

	private EXTTextureRg() {}
}
