/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class OESCompressedETC1RGB8Texture {

	/**
	 * Accepted by the &lt;internalformat&gt; parameter of CompressedTexImage2D: 
	 */
	public static final int GL_ETC1_RGB8_OES = 0x8D64;

	private OESCompressedETC1RGB8Texture() {}
}
