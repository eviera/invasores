/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opencl;

import org.lwjgl.*;
import java.nio.*;

public final class KHRInitializeMemory {

	/**
	 * cl_context_properties 
	 */
	public static final int CL_CONTEXT_MEMORY_INITIALIZE_KHR = 0x200E;

	/**
	 */
	public static final int CL_CONTEXT_MEMORY_INITIALIZE_LOCAL_KHR = 0x1,
		CL_CONTEXT_MEMORY_INITIALIZE_PRIVATE_KHR = 0x2;

	private KHRInitializeMemory() {}
}
